# datacleaning-python2

I have upload the .ipynb file. For dataset please go through the link below:

https://drive.google.com/file/d/1Dt4MjBe_7WE2DVsy7zakLoGoIa6MzhDV/view?usp=sharing

thank you
